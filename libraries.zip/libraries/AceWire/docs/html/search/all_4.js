var searchData=
[
  ['marplewireinterface_6',['MarpleWireInterface',['../classace__wire_1_1MarpleWireInterface.html',1,'ace_wire::MarpleWireInterface&lt; T_WIRE &gt;'],['../classace__wire_1_1MarpleWireInterface.html#ac22912f0f07d8c542f5101b7c62c410f',1,'ace_wire::MarpleWireInterface::MarpleWireInterface()']]]
];
